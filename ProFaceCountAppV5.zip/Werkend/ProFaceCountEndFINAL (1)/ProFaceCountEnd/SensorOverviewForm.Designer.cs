﻿namespace ProFaceCountEnd
{
    partial class SensorOverviewForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SensorOverviewForm));
            this.PnlOpen = new System.Windows.Forms.Panel();
            this.PnlChildOpen = new System.Windows.Forms.Panel();
            this.PnlBody = new System.Windows.Forms.Panel();
            this.DGSensorOverview = new System.Windows.Forms.DataGridView();
            this.Id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Description = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PnlHeaderSensorOverview = new System.Windows.Forms.Panel();
            this.BtnBack = new System.Windows.Forms.Button();
            this.LbHeaderSensorOverview = new System.Windows.Forms.Label();
            this.pictureBoxSearch = new System.Windows.Forms.PictureBox();
            this.TxtBxSearch2 = new System.Windows.Forms.TextBox();
            this.PnlOpen.SuspendLayout();
            this.PnlChildOpen.SuspendLayout();
            this.PnlBody.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGSensorOverview)).BeginInit();
            this.PnlHeaderSensorOverview.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSearch)).BeginInit();
            this.SuspendLayout();
            // 
            // PnlOpen
            // 
            this.PnlOpen.Controls.Add(this.PnlChildOpen);
            this.PnlOpen.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PnlOpen.Location = new System.Drawing.Point(0, 0);
            this.PnlOpen.Name = "PnlOpen";
            this.PnlOpen.Size = new System.Drawing.Size(730, 530);
            this.PnlOpen.TabIndex = 0;
            // 
            // PnlChildOpen
            // 
            this.PnlChildOpen.Controls.Add(this.PnlBody);
            this.PnlChildOpen.Controls.Add(this.PnlHeaderSensorOverview);
            this.PnlChildOpen.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PnlChildOpen.Location = new System.Drawing.Point(0, 0);
            this.PnlChildOpen.Name = "PnlChildOpen";
            this.PnlChildOpen.Size = new System.Drawing.Size(730, 530);
            this.PnlChildOpen.TabIndex = 0;
            // 
            // PnlBody
            // 
            this.PnlBody.Controls.Add(this.DGSensorOverview);
            this.PnlBody.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PnlBody.Location = new System.Drawing.Point(0, 49);
            this.PnlBody.Name = "PnlBody";
            this.PnlBody.Size = new System.Drawing.Size(730, 481);
            this.PnlBody.TabIndex = 3;
            // 
            // DGSensorOverview
            // 
            this.DGSensorOverview.AllowUserToAddRows = false;
            this.DGSensorOverview.AllowUserToDeleteRows = false;
            this.DGSensorOverview.AllowUserToResizeColumns = false;
            this.DGSensorOverview.AllowUserToResizeRows = false;
            this.DGSensorOverview.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DGSensorOverview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGSensorOverview.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Id,
            this.name,
            this.Description});
            this.DGSensorOverview.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DGSensorOverview.Location = new System.Drawing.Point(0, 0);
            this.DGSensorOverview.Name = "DGSensorOverview";
            this.DGSensorOverview.ReadOnly = true;
            this.DGSensorOverview.RowHeadersVisible = false;
            this.DGSensorOverview.RowHeadersWidth = 62;
            this.DGSensorOverview.Size = new System.Drawing.Size(730, 481);
            this.DGSensorOverview.TabIndex = 6;
            // 
            // Id
            // 
            this.Id.DataPropertyName = "Id";
            this.Id.HeaderText = "Id";
            this.Id.MinimumWidth = 8;
            this.Id.Name = "Id";
            this.Id.ReadOnly = true;
            // 
            // name
            // 
            this.name.DataPropertyName = "Name";
            this.name.HeaderText = "Name";
            this.name.MinimumWidth = 8;
            this.name.Name = "name";
            this.name.ReadOnly = true;
            // 
            // Description
            // 
            this.Description.DataPropertyName = "Description";
            this.Description.HeaderText = "Description";
            this.Description.MinimumWidth = 8;
            this.Description.Name = "Description";
            this.Description.ReadOnly = true;
            // 
            // PnlHeaderSensorOverview
            // 
            this.PnlHeaderSensorOverview.Controls.Add(this.TxtBxSearch2);
            this.PnlHeaderSensorOverview.Controls.Add(this.pictureBoxSearch);
            this.PnlHeaderSensorOverview.Controls.Add(this.BtnBack);
            this.PnlHeaderSensorOverview.Controls.Add(this.LbHeaderSensorOverview);
            this.PnlHeaderSensorOverview.Dock = System.Windows.Forms.DockStyle.Top;
            this.PnlHeaderSensorOverview.Location = new System.Drawing.Point(0, 0);
            this.PnlHeaderSensorOverview.MinimumSize = new System.Drawing.Size(730, 49);
            this.PnlHeaderSensorOverview.Name = "PnlHeaderSensorOverview";
            this.PnlHeaderSensorOverview.Size = new System.Drawing.Size(730, 49);
            this.PnlHeaderSensorOverview.TabIndex = 2;
            // 
            // BtnBack
            // 
            this.BtnBack.Location = new System.Drawing.Point(12, 11);
            this.BtnBack.Name = "BtnBack";
            this.BtnBack.Size = new System.Drawing.Size(80, 34);
            this.BtnBack.TabIndex = 8;
            this.BtnBack.Text = "Back";
            this.BtnBack.UseVisualStyleBackColor = true;
            this.BtnBack.Click += new System.EventHandler(this.BtnBack_Click);
            // 
            // LbHeaderSensorOverview
            // 
            this.LbHeaderSensorOverview.AutoSize = true;
            this.LbHeaderSensorOverview.Location = new System.Drawing.Point(103, 19);
            this.LbHeaderSensorOverview.Name = "LbHeaderSensorOverview";
            this.LbHeaderSensorOverview.Size = new System.Drawing.Size(139, 19);
            this.LbHeaderSensorOverview.TabIndex = 7;
            this.LbHeaderSensorOverview.Text = "Overview sensors";
            // 
            // pictureBoxSearch
            // 
            this.pictureBoxSearch.BackColor = System.Drawing.Color.White;
            this.pictureBoxSearch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxSearch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxSearch.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxSearch.Image")));
            this.pictureBoxSearch.Location = new System.Drawing.Point(679, 17);
            this.pictureBoxSearch.Name = "pictureBoxSearch";
            this.pictureBoxSearch.Size = new System.Drawing.Size(39, 21);
            this.pictureBoxSearch.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxSearch.TabIndex = 22;
            this.pictureBoxSearch.TabStop = false;
            this.pictureBoxSearch.Click += new System.EventHandler(this.pictureBoxSearch_Click);
            // 
            // TxtBxSearch2
            // 
            this.TxtBxSearch2.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtBxSearch2.Location = new System.Drawing.Point(509, 17);
            this.TxtBxSearch2.Name = "TxtBxSearch2";
            this.TxtBxSearch2.Size = new System.Drawing.Size(174, 21);
            this.TxtBxSearch2.TabIndex = 23;
            // 
            // SensorOverviewForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(730, 530);
            this.Controls.Add(this.PnlOpen);
            this.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "SensorOverviewForm";
            this.Text = "SensorOverviewForm";
            this.Load += new System.EventHandler(this.SensorOverviewForm_Load);
            this.PnlOpen.ResumeLayout(false);
            this.PnlChildOpen.ResumeLayout(false);
            this.PnlBody.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DGSensorOverview)).EndInit();
            this.PnlHeaderSensorOverview.ResumeLayout(false);
            this.PnlHeaderSensorOverview.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSearch)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel PnlOpen;
        private System.Windows.Forms.Panel PnlChildOpen;
        private System.Windows.Forms.Panel PnlHeaderSensorOverview;
        private System.Windows.Forms.Button BtnBack;
        private System.Windows.Forms.Label LbHeaderSensorOverview;
        private System.Windows.Forms.Panel PnlBody;
        private System.Windows.Forms.DataGridView DGSensorOverview;
        private System.Windows.Forms.DataGridViewTextBoxColumn Id;
        private System.Windows.Forms.DataGridViewTextBoxColumn name;
        private System.Windows.Forms.DataGridViewTextBoxColumn Description;
        private System.Windows.Forms.PictureBox pictureBoxSearch;
        private System.Windows.Forms.TextBox TxtBxSearch2;
    }
}