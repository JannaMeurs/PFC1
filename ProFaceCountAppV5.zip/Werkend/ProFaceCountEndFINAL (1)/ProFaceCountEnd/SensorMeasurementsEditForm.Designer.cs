﻿namespace ProFaceCountEnd
{
    partial class SensorMeasurementsEditForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.PnlSensorMeasurement = new System.Windows.Forms.Panel();
            this.DGSensorMeasurements = new System.Windows.Forms.DataGridView();
            this.EntryId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PeopleIn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PeopleOut = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TimeStamp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewButtonColumn1 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.dataGridViewButtonColumn2 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.PnlHeaderSensorMeasurement = new System.Windows.Forms.Panel();
            this.Btn = new System.Windows.Forms.Button();
            this.LbHeaderSensor = new System.Windows.Forms.Label();
            this.PnlOpen = new System.Windows.Forms.Panel();
            this.PnlSensorMeasurement.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGSensorMeasurements)).BeginInit();
            this.PnlHeaderSensorMeasurement.SuspendLayout();
            this.PnlOpen.SuspendLayout();
            this.SuspendLayout();
            // 
            // PnlSensorMeasurement
            // 
            this.PnlSensorMeasurement.Controls.Add(this.DGSensorMeasurements);
            this.PnlSensorMeasurement.Controls.Add(this.PnlHeaderSensorMeasurement);
            this.PnlSensorMeasurement.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PnlSensorMeasurement.Location = new System.Drawing.Point(0, 0);
            this.PnlSensorMeasurement.Name = "PnlSensorMeasurement";
            this.PnlSensorMeasurement.Size = new System.Drawing.Size(730, 530);
            this.PnlSensorMeasurement.TabIndex = 0;
            // 
            // DGSensorMeasurements
            // 
            this.DGSensorMeasurements.AllowUserToAddRows = false;
            this.DGSensorMeasurements.AllowUserToDeleteRows = false;
            this.DGSensorMeasurements.AllowUserToResizeColumns = false;
            this.DGSensorMeasurements.AllowUserToResizeRows = false;
            this.DGSensorMeasurements.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DGSensorMeasurements.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGSensorMeasurements.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.EntryId,
            this.PeopleIn,
            this.PeopleOut,
            this.TimeStamp,
            this.dataGridViewButtonColumn1,
            this.dataGridViewButtonColumn2});
            this.DGSensorMeasurements.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DGSensorMeasurements.Location = new System.Drawing.Point(0, 49);
            this.DGSensorMeasurements.Name = "DGSensorMeasurements";
            this.DGSensorMeasurements.ReadOnly = true;
            this.DGSensorMeasurements.RowHeadersVisible = false;
            this.DGSensorMeasurements.RowHeadersWidth = 62;
            this.DGSensorMeasurements.Size = new System.Drawing.Size(730, 481);
            this.DGSensorMeasurements.TabIndex = 11;
            this.DGSensorMeasurements.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGSensorMeasurements_CellContentClick);
            // 
            // EntryId
            // 
            this.EntryId.DataPropertyName = "EntryId";
            this.EntryId.HeaderText = "Id";
            this.EntryId.Name = "EntryId";
            this.EntryId.ReadOnly = true;
            // 
            // PeopleIn
            // 
            this.PeopleIn.DataPropertyName = "PeopleIn";
            this.PeopleIn.HeaderText = "People in";
            this.PeopleIn.Name = "PeopleIn";
            this.PeopleIn.ReadOnly = true;
            // 
            // PeopleOut
            // 
            this.PeopleOut.DataPropertyName = "PeopleOut";
            this.PeopleOut.HeaderText = "People out";
            this.PeopleOut.Name = "PeopleOut";
            this.PeopleOut.ReadOnly = true;
            // 
            // TimeStamp
            // 
            this.TimeStamp.DataPropertyName = "TimeStamp";
            this.TimeStamp.HeaderText = "Timestamp";
            this.TimeStamp.Name = "TimeStamp";
            this.TimeStamp.ReadOnly = true;
            // 
            // dataGridViewButtonColumn1
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightGray;
            this.dataGridViewButtonColumn1.DefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewButtonColumn1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.dataGridViewButtonColumn1.HeaderText = "";
            this.dataGridViewButtonColumn1.MinimumWidth = 8;
            this.dataGridViewButtonColumn1.Name = "dataGridViewButtonColumn1";
            this.dataGridViewButtonColumn1.ReadOnly = true;
            this.dataGridViewButtonColumn1.Text = "Edit";
            this.dataGridViewButtonColumn1.UseColumnTextForButtonValue = true;
            // 
            // dataGridViewButtonColumn2
            // 
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.LightGray;
            this.dataGridViewButtonColumn2.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewButtonColumn2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.dataGridViewButtonColumn2.HeaderText = "";
            this.dataGridViewButtonColumn2.MinimumWidth = 8;
            this.dataGridViewButtonColumn2.Name = "dataGridViewButtonColumn2";
            this.dataGridViewButtonColumn2.ReadOnly = true;
            this.dataGridViewButtonColumn2.Text = "Delete";
            this.dataGridViewButtonColumn2.UseColumnTextForButtonValue = true;
            // 
            // PnlHeaderSensorMeasurement
            // 
            this.PnlHeaderSensorMeasurement.Controls.Add(this.Btn);
            this.PnlHeaderSensorMeasurement.Controls.Add(this.LbHeaderSensor);
            this.PnlHeaderSensorMeasurement.Dock = System.Windows.Forms.DockStyle.Top;
            this.PnlHeaderSensorMeasurement.Location = new System.Drawing.Point(0, 0);
            this.PnlHeaderSensorMeasurement.Name = "PnlHeaderSensorMeasurement";
            this.PnlHeaderSensorMeasurement.Size = new System.Drawing.Size(730, 49);
            this.PnlHeaderSensorMeasurement.TabIndex = 10;
            // 
            // Btn
            // 
            this.Btn.Location = new System.Drawing.Point(12, 11);
            this.Btn.Name = "Btn";
            this.Btn.Size = new System.Drawing.Size(80, 30);
            this.Btn.TabIndex = 8;
            this.Btn.Text = "Back";
            this.Btn.UseVisualStyleBackColor = true;
            this.Btn.Click += new System.EventHandler(this.Btn_Click);
            // 
            // LbHeaderSensor
            // 
            this.LbHeaderSensor.AutoSize = true;
            this.LbHeaderSensor.Location = new System.Drawing.Point(143, 17);
            this.LbHeaderSensor.Name = "LbHeaderSensor";
            this.LbHeaderSensor.Size = new System.Drawing.Size(176, 19);
            this.LbHeaderSensor.TabIndex = 6;
            this.LbHeaderSensor.Text = "Sensor measurements";
            this.LbHeaderSensor.Click += new System.EventHandler(this.LbHeaderSensor_Click);
            // 
            // PnlOpen
            // 
            this.PnlOpen.Controls.Add(this.PnlSensorMeasurement);
            this.PnlOpen.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PnlOpen.Location = new System.Drawing.Point(0, 0);
            this.PnlOpen.Name = "PnlOpen";
            this.PnlOpen.Size = new System.Drawing.Size(730, 530);
            this.PnlOpen.TabIndex = 1;
            // 
            // SensorMeasurementsEditForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(730, 530);
            this.Controls.Add(this.PnlOpen);
            this.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "SensorMeasurementsEditForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SensorMeasurementsEditForm";
            this.Load += new System.EventHandler(this.SensorMeasurementsEditForm_Load);
            this.PnlSensorMeasurement.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DGSensorMeasurements)).EndInit();
            this.PnlHeaderSensorMeasurement.ResumeLayout(false);
            this.PnlHeaderSensorMeasurement.PerformLayout();
            this.PnlOpen.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel PnlSensorMeasurement;
        private System.Windows.Forms.Panel PnlHeaderSensorMeasurement;
        private System.Windows.Forms.Label LbHeaderSensor;
        private System.Windows.Forms.DataGridView DGSensorMeasurements;
        private System.Windows.Forms.Button Btn;
        private System.Windows.Forms.DataGridViewTextBoxColumn EntryId;
        private System.Windows.Forms.DataGridViewTextBoxColumn PeopleIn;
        private System.Windows.Forms.DataGridViewTextBoxColumn PeopleOut;
        private System.Windows.Forms.DataGridViewTextBoxColumn TimeStamp;
        private System.Windows.Forms.DataGridViewButtonColumn dataGridViewButtonColumn1;
        private System.Windows.Forms.DataGridViewButtonColumn dataGridViewButtonColumn2;
        private System.Windows.Forms.Panel PnlOpen;
    }
}