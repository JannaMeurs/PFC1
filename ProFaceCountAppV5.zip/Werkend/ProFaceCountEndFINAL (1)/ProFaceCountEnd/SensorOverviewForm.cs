﻿using ProFaceCountEnd.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProFaceCountEnd
{
    public partial class SensorOverviewForm : Form
    {
        DAL dal;
        public SensorOverviewForm(DAL dal)
        {
            InitializeComponent();
            this.dal = dal;
            dal.FillSensorOverview();
            DGSensorOverview.DataSource = dal.SensorOverview;
        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void SensorOverviewForm_Load(object sender, EventArgs e)
        {
            DGSensorOverview.Columns["Id"].Visible = false;
            DGSensorOverview.Columns["Location"].Visible = false;
            DGSensorOverview.AutoGenerateColumns = false;
            DGSensorOverview.DataSource = dal.SensorOverview;
        }

        private void pictureBoxSearch_Click(object sender, EventArgs e)
        {
            dal.SearchSensors(TxtBxSearch2.Text);
        }
    }
}
