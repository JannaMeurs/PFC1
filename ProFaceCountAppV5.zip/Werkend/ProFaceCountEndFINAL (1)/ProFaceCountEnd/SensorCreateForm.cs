﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ProFaceCountEnd.Classes;

namespace ProFaceCountEnd
{
    public partial class SensorCreateForm : Form
    {
        DAL dal;
        Location location;
        public Form activeForm = null; //Sets activeform to Null.
        public SensorCreateForm(DAL dal, Location location)
        {
            InitializeComponent();
            this.dal = dal;
            this.location = location;
            
            dal.FillSensorListFromDatabase();
        }

        public void openChildForm(Form childForm)
        {
            //Opens forms inside 'PnlPage'.
            if (activeForm != null)
            {
                activeForm.Close();
            }
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            PnlOpen.Controls.Add(childForm);
            PnlOpen.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
        }
        private void DGSensor_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void BtnCloseApp_Click(object sender, EventArgs e)
        {
            //this.Close();
        }

        private void BtnCreateSensor_Click(object sender, EventArgs e)
        {
            Sensor sensor = new Sensor(0, TbNameSensor.Text, TbDescriptionSensor.Text);
            dal.CreateSensor(sensor,location);
            dal.FillSensorListFromDatabase();
            foreach (Sensor x in location.Sensors)
            {
                Console.WriteLine(x.Name);
            }
        }

        private void SensorCreateForm_Load(object sender, EventArgs e)
        {
            DGSensor.AutoGenerateColumns = false;
            DGSensor.DataSource = location.Sensors;
        }

        private void DGSensor_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            var row = e.RowIndex;
            var column = e.ColumnIndex;
            if (column == 3)
            {
                var sensor = DGSensor.CurrentRow.DataBoundItem as Sensor;
                openChildForm(new SensorEditForm(sensor, dal));
                
                //SensorEditForm openForm = new SensorEditForm(dal, dal.Sensors[row]);
                //openForm.Show();
            }
            else if (column == 4)
            {
                if (MessageBox.Show("Wilt u dit verwijderen?", "Message", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    var sensor = DGSensor.CurrentRow.DataBoundItem as Sensor;
                    dal.DeleteSensorCascade(sensor);
                    dal.FillSensorListFromDatabase();
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBoxSearch_Click(object sender, EventArgs e)
        {
             
        }
    }
}
