﻿using ProFaceCountEnd.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProFaceCountEnd
{
    public partial class SensorMeasurementSpecificEdit : Form
    {
        DAL dal;
        SensorMeasurement measurement;

        public SensorMeasurementSpecificEdit(SensorMeasurement measurement, DAL dal)
        {
            InitializeComponent();
            this.measurement = measurement;
            this.dal = dal;
        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void LbEditPeopleOut_Click(object sender, EventArgs e)
        {

        }

        private void SensorMeasurementSpecificEdit_Load(object sender, EventArgs e)
        {
            TbEditPeopleIn.Text = measurement.PeopleIn.ToString();
            TbEditPeopleOut.Text = measurement.PeopleOut.ToString();
            TbEditDate.Text = measurement.TimeStamp.ToString();
        }

        private void btnMeasurementEdit_Click(object sender, EventArgs e)
        {
            dal.UpdateMeasurement(measurement.EntryId, Int32.Parse(TbEditPeopleIn.Text), Int32.Parse(TbEditPeopleOut.Text), DateTime.Parse(TbEditDate.Text));
            dal.FillMeasurementsFromDatabase();
            this.Hide();
        }
    }
}
