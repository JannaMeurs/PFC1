﻿namespace ProFaceCountEnd
{
    partial class SensorCreateForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SensorCreateForm));
            this.PnlHeaderSensor = new System.Windows.Forms.Panel();
            this.BtnBack = new System.Windows.Forms.Button();
            this.LbHeaderSensor = new System.Windows.Forms.Label();
            this.PnlFooterSensor = new System.Windows.Forms.Panel();
            this.BtnCreateSensor = new System.Windows.Forms.Button();
            this.TbDescriptionSensor = new System.Windows.Forms.TextBox();
            this.LbMaxPersonsSensor = new System.Windows.Forms.Label();
            this.LbNameSensor = new System.Windows.Forms.Label();
            this.TbNameSensor = new System.Windows.Forms.TextBox();
            this.DGSensor = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Descriptions = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewButtonColumn1 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.dataGridViewButtonColumn2 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.PnlChildOpen = new System.Windows.Forms.Panel();
            this.PnlBody = new System.Windows.Forms.Panel();
            this.PnlOpen = new System.Windows.Forms.Panel();
            this.pictureBoxSearch = new System.Windows.Forms.PictureBox();
            this.TxtBxSearch2 = new System.Windows.Forms.TextBox();
            this.PnlHeaderSensor.SuspendLayout();
            this.PnlFooterSensor.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGSensor)).BeginInit();
            this.PnlChildOpen.SuspendLayout();
            this.PnlBody.SuspendLayout();
            this.PnlOpen.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSearch)).BeginInit();
            this.SuspendLayout();
            // 
            // PnlHeaderSensor
            // 
            this.PnlHeaderSensor.Controls.Add(this.TxtBxSearch2);
            this.PnlHeaderSensor.Controls.Add(this.pictureBoxSearch);
            this.PnlHeaderSensor.Controls.Add(this.BtnBack);
            this.PnlHeaderSensor.Controls.Add(this.LbHeaderSensor);
            this.PnlHeaderSensor.Dock = System.Windows.Forms.DockStyle.Top;
            this.PnlHeaderSensor.Location = new System.Drawing.Point(0, 0);
            this.PnlHeaderSensor.Name = "PnlHeaderSensor";
            this.PnlHeaderSensor.Size = new System.Drawing.Size(730, 49);
            this.PnlHeaderSensor.TabIndex = 9;
            // 
            // BtnBack
            // 
            this.BtnBack.Location = new System.Drawing.Point(12, 10);
            this.BtnBack.Name = "BtnBack";
            this.BtnBack.Size = new System.Drawing.Size(84, 34);
            this.BtnBack.TabIndex = 7;
            this.BtnBack.Text = "Back";
            this.BtnBack.UseVisualStyleBackColor = true;
            this.BtnBack.Click += new System.EventHandler(this.button1_Click);
            // 
            // LbHeaderSensor
            // 
            this.LbHeaderSensor.AutoSize = true;
            this.LbHeaderSensor.Location = new System.Drawing.Point(102, 18);
            this.LbHeaderSensor.Name = "LbHeaderSensor";
            this.LbHeaderSensor.Size = new System.Drawing.Size(64, 19);
            this.LbHeaderSensor.TabIndex = 6;
            this.LbHeaderSensor.Text = "Sensors";
            // 
            // PnlFooterSensor
            // 
            this.PnlFooterSensor.Controls.Add(this.BtnCreateSensor);
            this.PnlFooterSensor.Controls.Add(this.TbDescriptionSensor);
            this.PnlFooterSensor.Controls.Add(this.LbMaxPersonsSensor);
            this.PnlFooterSensor.Controls.Add(this.LbNameSensor);
            this.PnlFooterSensor.Controls.Add(this.TbNameSensor);
            this.PnlFooterSensor.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.PnlFooterSensor.Location = new System.Drawing.Point(0, 461);
            this.PnlFooterSensor.Name = "PnlFooterSensor";
            this.PnlFooterSensor.Size = new System.Drawing.Size(730, 69);
            this.PnlFooterSensor.TabIndex = 11;
            // 
            // BtnCreateSensor
            // 
            this.BtnCreateSensor.Location = new System.Drawing.Point(594, 13);
            this.BtnCreateSensor.Name = "BtnCreateSensor";
            this.BtnCreateSensor.Size = new System.Drawing.Size(100, 40);
            this.BtnCreateSensor.TabIndex = 4;
            this.BtnCreateSensor.Text = "Add";
            this.BtnCreateSensor.UseVisualStyleBackColor = true;
            this.BtnCreateSensor.Click += new System.EventHandler(this.BtnCreateSensor_Click);
            // 
            // TbDescriptionSensor
            // 
            this.TbDescriptionSensor.Location = new System.Drawing.Point(384, 18);
            this.TbDescriptionSensor.Name = "TbDescriptionSensor";
            this.TbDescriptionSensor.Size = new System.Drawing.Size(184, 27);
            this.TbDescriptionSensor.TabIndex = 3;
            // 
            // LbMaxPersonsSensor
            // 
            this.LbMaxPersonsSensor.AutoSize = true;
            this.LbMaxPersonsSensor.Location = new System.Drawing.Point(259, 22);
            this.LbMaxPersonsSensor.Name = "LbMaxPersonsSensor";
            this.LbMaxPersonsSensor.Size = new System.Drawing.Size(94, 19);
            this.LbMaxPersonsSensor.TabIndex = 2;
            this.LbMaxPersonsSensor.Text = "Description";
            // 
            // LbNameSensor
            // 
            this.LbNameSensor.AutoSize = true;
            this.LbNameSensor.Location = new System.Drawing.Point(45, 22);
            this.LbNameSensor.Name = "LbNameSensor";
            this.LbNameSensor.Size = new System.Drawing.Size(58, 19);
            this.LbNameSensor.TabIndex = 0;
            this.LbNameSensor.Text = "Name";
            // 
            // TbNameSensor
            // 
            this.TbNameSensor.Location = new System.Drawing.Point(121, 18);
            this.TbNameSensor.Name = "TbNameSensor";
            this.TbNameSensor.Size = new System.Drawing.Size(118, 27);
            this.TbNameSensor.TabIndex = 1;
            // 
            // DGSensor
            // 
            this.DGSensor.AllowUserToAddRows = false;
            this.DGSensor.AllowUserToDeleteRows = false;
            this.DGSensor.AllowUserToResizeColumns = false;
            this.DGSensor.AllowUserToResizeRows = false;
            this.DGSensor.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DGSensor.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGSensor.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.Descriptions,
            this.dataGridViewButtonColumn1,
            this.dataGridViewButtonColumn2});
            this.DGSensor.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DGSensor.Location = new System.Drawing.Point(0, 0);
            this.DGSensor.Name = "DGSensor";
            this.DGSensor.ReadOnly = true;
            this.DGSensor.RowHeadersVisible = false;
            this.DGSensor.RowHeadersWidth = 62;
            this.DGSensor.Size = new System.Drawing.Size(730, 412);
            this.DGSensor.TabIndex = 5;
            this.DGSensor.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGSensor_CellContentClick_1);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Id";
            this.dataGridViewTextBoxColumn1.HeaderText = "Id";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Name";
            this.dataGridViewTextBoxColumn2.HeaderText = "Name";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // Descriptions
            // 
            this.Descriptions.DataPropertyName = "Description";
            this.Descriptions.HeaderText = "Description";
            this.Descriptions.MinimumWidth = 8;
            this.Descriptions.Name = "Descriptions";
            this.Descriptions.ReadOnly = true;
            // 
            // dataGridViewButtonColumn1
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightGray;
            this.dataGridViewButtonColumn1.DefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewButtonColumn1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.dataGridViewButtonColumn1.HeaderText = "";
            this.dataGridViewButtonColumn1.MinimumWidth = 8;
            this.dataGridViewButtonColumn1.Name = "dataGridViewButtonColumn1";
            this.dataGridViewButtonColumn1.ReadOnly = true;
            this.dataGridViewButtonColumn1.Text = "Edit";
            this.dataGridViewButtonColumn1.UseColumnTextForButtonValue = true;
            // 
            // dataGridViewButtonColumn2
            // 
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.LightGray;
            this.dataGridViewButtonColumn2.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewButtonColumn2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.dataGridViewButtonColumn2.HeaderText = "";
            this.dataGridViewButtonColumn2.MinimumWidth = 8;
            this.dataGridViewButtonColumn2.Name = "dataGridViewButtonColumn2";
            this.dataGridViewButtonColumn2.ReadOnly = true;
            this.dataGridViewButtonColumn2.Text = "Delete";
            this.dataGridViewButtonColumn2.UseColumnTextForButtonValue = true;
            // 
            // PnlChildOpen
            // 
            this.PnlChildOpen.Controls.Add(this.PnlBody);
            this.PnlChildOpen.Controls.Add(this.PnlHeaderSensor);
            this.PnlChildOpen.Controls.Add(this.PnlFooterSensor);
            this.PnlChildOpen.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PnlChildOpen.Location = new System.Drawing.Point(0, 0);
            this.PnlChildOpen.Name = "PnlChildOpen";
            this.PnlChildOpen.Size = new System.Drawing.Size(730, 530);
            this.PnlChildOpen.TabIndex = 13;
            // 
            // PnlBody
            // 
            this.PnlBody.Controls.Add(this.DGSensor);
            this.PnlBody.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PnlBody.Location = new System.Drawing.Point(0, 49);
            this.PnlBody.Name = "PnlBody";
            this.PnlBody.Size = new System.Drawing.Size(730, 412);
            this.PnlBody.TabIndex = 13;
            // 
            // PnlOpen
            // 
            this.PnlOpen.Controls.Add(this.PnlChildOpen);
            this.PnlOpen.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PnlOpen.Location = new System.Drawing.Point(0, 0);
            this.PnlOpen.Name = "PnlOpen";
            this.PnlOpen.Size = new System.Drawing.Size(730, 530);
            this.PnlOpen.TabIndex = 14;
            // 
            // pictureBoxSearch
            // 
            this.pictureBoxSearch.BackColor = System.Drawing.Color.White;
            this.pictureBoxSearch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxSearch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxSearch.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxSearch.Image")));
            this.pictureBoxSearch.Location = new System.Drawing.Point(679, 16);
            this.pictureBoxSearch.Name = "pictureBoxSearch";
            this.pictureBoxSearch.Size = new System.Drawing.Size(39, 21);
            this.pictureBoxSearch.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxSearch.TabIndex = 20;
            this.pictureBoxSearch.TabStop = false;
            this.pictureBoxSearch.Click += new System.EventHandler(this.pictureBoxSearch_Click);
            // 
            // TxtBxSearch2
            // 
            this.TxtBxSearch2.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtBxSearch2.Location = new System.Drawing.Point(508, 16);
            this.TxtBxSearch2.Name = "TxtBxSearch2";
            this.TxtBxSearch2.Size = new System.Drawing.Size(174, 21);
            this.TxtBxSearch2.TabIndex = 21;
            // 
            // SensorCreateForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(730, 530);
            this.Controls.Add(this.PnlOpen);
            this.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MinimumSize = new System.Drawing.Size(730, 530);
            this.Name = "SensorCreateForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SensorCreateForm";
            this.Load += new System.EventHandler(this.SensorCreateForm_Load);
            this.PnlHeaderSensor.ResumeLayout(false);
            this.PnlHeaderSensor.PerformLayout();
            this.PnlFooterSensor.ResumeLayout(false);
            this.PnlFooterSensor.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGSensor)).EndInit();
            this.PnlChildOpen.ResumeLayout(false);
            this.PnlBody.ResumeLayout(false);
            this.PnlOpen.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSearch)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel PnlHeaderSensor;
        private System.Windows.Forms.Label LbHeaderSensor;
        private System.Windows.Forms.Panel PnlFooterSensor;
        private System.Windows.Forms.Button BtnCreateSensor;
        private System.Windows.Forms.TextBox TbDescriptionSensor;
        private System.Windows.Forms.Label LbMaxPersonsSensor;
        private System.Windows.Forms.Label LbNameSensor;
        private System.Windows.Forms.TextBox TbNameSensor;
        private System.Windows.Forms.DataGridView DGSensor;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Descriptions;
        private System.Windows.Forms.DataGridViewButtonColumn dataGridViewButtonColumn1;
        private System.Windows.Forms.DataGridViewButtonColumn dataGridViewButtonColumn2;
        private System.Windows.Forms.Button BtnBack;
        private System.Windows.Forms.Panel PnlChildOpen;
        private System.Windows.Forms.Panel PnlOpen;
        private System.Windows.Forms.Panel PnlBody;
        private System.Windows.Forms.PictureBox pictureBoxSearch;
        private System.Windows.Forms.TextBox TxtBxSearch2;
    }
}