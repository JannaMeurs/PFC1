﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ProFaceCountEnd.Classes;

namespace ProFaceCountEnd
{
    public partial class SensorMeasurementsEditForm : Form
    {
        DAL dal;
        Sensor sensor;
        public Form activeForm = null; //Sets activeform to Null.
        public SensorMeasurementsEditForm(DAL dal, Sensor sensor)
            
        {
            InitializeComponent();
            this.dal = dal;
            this.sensor = sensor;
            dal.FillMeasurementsFromDatabase();

        }
        public void openChildForm(Form childForm)
        {
            //Opens forms inside 'PnlPage'.
            if (activeForm != null)
            {
                activeForm.Close();
            }
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            PnlOpen.Controls.Add(childForm);
            PnlOpen.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
        }
        private void LbHeaderSensor_Click(object sender, EventArgs e)
        {

        }

        private void BtnCloseApp_Click(object sender, EventArgs e)
        {

           


            //this.Close();
        }

        private void DGSensorMeasurements_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            var row = e.RowIndex;
            var column = e.ColumnIndex;
            if (column == 4)
            {
                var Measurement = DGSensorMeasurements.CurrentRow.DataBoundItem as SensorMeasurement;
                openChildForm(new SensorMeasurementSpecificEdit(Measurement, dal));


            }
            else if (column == 5)
            {
                if (MessageBox.Show("Wilt u dit verwijderen?", "Message", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    var Measurement = DGSensorMeasurements.CurrentRow.DataBoundItem as SensorMeasurement;
                    dal.DeleteMeasurement(Measurement);
                    dal.FillMeasurementsFromDatabase();
                }
            }
        }

        private void SensorMeasurementsEditForm_Load(object sender, EventArgs e)
        {
            
            DGSensorMeasurements.AutoGenerateColumns = false;
            DGSensorMeasurements.DataSource = sensor.Measurements;
        }

        private void Btn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
