﻿namespace ProFaceCountEnd
{
    partial class SensorMeasurementSpecificEdit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PnlOpen = new System.Windows.Forms.Panel();
            this.PnlChildOpen = new System.Windows.Forms.Panel();
            this.btnMeasurementEdit = new System.Windows.Forms.Button();
            this.TbEditDate = new System.Windows.Forms.TextBox();
            this.LbEditDate = new System.Windows.Forms.Label();
            this.TbEditPeopleOut = new System.Windows.Forms.TextBox();
            this.TbEditPeopleIn = new System.Windows.Forms.TextBox();
            this.LbEditPeopleOut = new System.Windows.Forms.Label();
            this.LbEditPeopleIn = new System.Windows.Forms.Label();
            this.PnlHeaderEditMeasurement = new System.Windows.Forms.Panel();
            this.BtnBack = new System.Windows.Forms.Button();
            this.LbHeaderMeasurement = new System.Windows.Forms.Label();
            this.PnlOpen.SuspendLayout();
            this.PnlChildOpen.SuspendLayout();
            this.PnlHeaderEditMeasurement.SuspendLayout();
            this.SuspendLayout();
            // 
            // PnlOpen
            // 
            this.PnlOpen.Controls.Add(this.PnlChildOpen);
            this.PnlOpen.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PnlOpen.Location = new System.Drawing.Point(0, 0);
            this.PnlOpen.Name = "PnlOpen";
            this.PnlOpen.Size = new System.Drawing.Size(730, 530);
            this.PnlOpen.TabIndex = 0;
            // 
            // PnlChildOpen
            // 
            this.PnlChildOpen.Controls.Add(this.btnMeasurementEdit);
            this.PnlChildOpen.Controls.Add(this.TbEditDate);
            this.PnlChildOpen.Controls.Add(this.LbEditDate);
            this.PnlChildOpen.Controls.Add(this.TbEditPeopleOut);
            this.PnlChildOpen.Controls.Add(this.TbEditPeopleIn);
            this.PnlChildOpen.Controls.Add(this.LbEditPeopleOut);
            this.PnlChildOpen.Controls.Add(this.LbEditPeopleIn);
            this.PnlChildOpen.Controls.Add(this.PnlHeaderEditMeasurement);
            this.PnlChildOpen.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PnlChildOpen.Location = new System.Drawing.Point(0, 0);
            this.PnlChildOpen.Name = "PnlChildOpen";
            this.PnlChildOpen.Size = new System.Drawing.Size(730, 530);
            this.PnlChildOpen.TabIndex = 0;
            // 
            // btnMeasurementEdit
            // 
            this.btnMeasurementEdit.Location = new System.Drawing.Point(245, 331);
            this.btnMeasurementEdit.Name = "btnMeasurementEdit";
            this.btnMeasurementEdit.Size = new System.Drawing.Size(162, 41);
            this.btnMeasurementEdit.TabIndex = 23;
            this.btnMeasurementEdit.Text = "Edit";
            this.btnMeasurementEdit.UseVisualStyleBackColor = true;
            this.btnMeasurementEdit.Click += new System.EventHandler(this.btnMeasurementEdit_Click);
            // 
            // TbEditDate
            // 
            this.TbEditDate.Location = new System.Drawing.Point(245, 286);
            this.TbEditDate.Name = "TbEditDate";
            this.TbEditDate.Size = new System.Drawing.Size(162, 27);
            this.TbEditDate.TabIndex = 22;
            // 
            // LbEditDate
            // 
            this.LbEditDate.AutoSize = true;
            this.LbEditDate.Location = new System.Drawing.Point(241, 264);
            this.LbEditDate.Name = "LbEditDate";
            this.LbEditDate.Size = new System.Drawing.Size(45, 19);
            this.LbEditDate.TabIndex = 21;
            this.LbEditDate.Text = "Date";
            // 
            // TbEditPeopleOut
            // 
            this.TbEditPeopleOut.Location = new System.Drawing.Point(245, 225);
            this.TbEditPeopleOut.Name = "TbEditPeopleOut";
            this.TbEditPeopleOut.Size = new System.Drawing.Size(162, 27);
            this.TbEditPeopleOut.TabIndex = 20;
            // 
            // TbEditPeopleIn
            // 
            this.TbEditPeopleIn.Location = new System.Drawing.Point(245, 160);
            this.TbEditPeopleIn.Name = "TbEditPeopleIn";
            this.TbEditPeopleIn.Size = new System.Drawing.Size(162, 27);
            this.TbEditPeopleIn.TabIndex = 19;
            // 
            // LbEditPeopleOut
            // 
            this.LbEditPeopleOut.AutoSize = true;
            this.LbEditPeopleOut.Location = new System.Drawing.Point(241, 203);
            this.LbEditPeopleOut.Name = "LbEditPeopleOut";
            this.LbEditPeopleOut.Size = new System.Drawing.Size(91, 19);
            this.LbEditPeopleOut.TabIndex = 18;
            this.LbEditPeopleOut.Text = "People out";
            this.LbEditPeopleOut.Click += new System.EventHandler(this.LbEditPeopleOut_Click);
            // 
            // LbEditPeopleIn
            // 
            this.LbEditPeopleIn.AutoSize = true;
            this.LbEditPeopleIn.Location = new System.Drawing.Point(241, 138);
            this.LbEditPeopleIn.Name = "LbEditPeopleIn";
            this.LbEditPeopleIn.Size = new System.Drawing.Size(81, 19);
            this.LbEditPeopleIn.TabIndex = 17;
            this.LbEditPeopleIn.Text = "People in";
            // 
            // PnlHeaderEditMeasurement
            // 
            this.PnlHeaderEditMeasurement.Controls.Add(this.BtnBack);
            this.PnlHeaderEditMeasurement.Controls.Add(this.LbHeaderMeasurement);
            this.PnlHeaderEditMeasurement.Dock = System.Windows.Forms.DockStyle.Top;
            this.PnlHeaderEditMeasurement.Location = new System.Drawing.Point(0, 0);
            this.PnlHeaderEditMeasurement.MinimumSize = new System.Drawing.Size(730, 49);
            this.PnlHeaderEditMeasurement.Name = "PnlHeaderEditMeasurement";
            this.PnlHeaderEditMeasurement.Size = new System.Drawing.Size(730, 49);
            this.PnlHeaderEditMeasurement.TabIndex = 1;
            // 
            // BtnBack
            // 
            this.BtnBack.Location = new System.Drawing.Point(12, 11);
            this.BtnBack.Name = "BtnBack";
            this.BtnBack.Size = new System.Drawing.Size(80, 34);
            this.BtnBack.TabIndex = 8;
            this.BtnBack.Text = "Back";
            this.BtnBack.UseVisualStyleBackColor = true;
            this.BtnBack.Click += new System.EventHandler(this.BtnBack_Click);
            // 
            // LbHeaderMeasurement
            // 
            this.LbHeaderMeasurement.AutoSize = true;
            this.LbHeaderMeasurement.Location = new System.Drawing.Point(103, 19);
            this.LbHeaderMeasurement.Name = "LbHeaderMeasurement";
            this.LbHeaderMeasurement.Size = new System.Drawing.Size(148, 19);
            this.LbHeaderMeasurement.TabIndex = 7;
            this.LbHeaderMeasurement.Text = "Edit measurement";
            // 
            // SensorMeasurementSpecificEdit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(730, 530);
            this.Controls.Add(this.PnlOpen);
            this.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "SensorMeasurementSpecificEdit";
            this.Text = "SensorMeasurementSpecificEdit";
            this.Load += new System.EventHandler(this.SensorMeasurementSpecificEdit_Load);
            this.PnlOpen.ResumeLayout(false);
            this.PnlChildOpen.ResumeLayout(false);
            this.PnlChildOpen.PerformLayout();
            this.PnlHeaderEditMeasurement.ResumeLayout(false);
            this.PnlHeaderEditMeasurement.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel PnlOpen;
        private System.Windows.Forms.Panel PnlChildOpen;
        private System.Windows.Forms.Panel PnlHeaderEditMeasurement;
        private System.Windows.Forms.Button BtnBack;
        private System.Windows.Forms.Label LbHeaderMeasurement;
        private System.Windows.Forms.Label LbEditPeopleIn;
        private System.Windows.Forms.Label LbEditPeopleOut;
        private System.Windows.Forms.TextBox TbEditPeopleOut;
        private System.Windows.Forms.TextBox TbEditPeopleIn;
        private System.Windows.Forms.TextBox TbEditDate;
        private System.Windows.Forms.Label LbEditDate;
        private System.Windows.Forms.Button btnMeasurementEdit;
    }
}