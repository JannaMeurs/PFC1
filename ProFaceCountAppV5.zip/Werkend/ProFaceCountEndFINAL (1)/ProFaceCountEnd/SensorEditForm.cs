﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ProFaceCountEnd.Classes;

namespace ProFaceCountEnd
{
    public partial class SensorEditForm : Form
    {
        DAL dal;
        Sensor sensor;
        public Form activeForm = null; //Sets activeform to Null.
        public SensorEditForm(Sensor sensor, DAL dal)
        {
            InitializeComponent();
            this.dal = dal;
            this.sensor = sensor;
        }

        public void openChildForm(Form childForm)
        {
            //Opens forms inside 'PnlPage'.
            if (activeForm != null)
            {
                activeForm.Close();
            }
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            PnlOpen.Controls.Add(childForm);
            PnlOpen.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
        }
        private void BtnCloseApp_Click(object sender, EventArgs e)
        {
            //this.Close();
        }

        private void SensorEditForm_Load(object sender, EventArgs e)
        {
            TbNameEditSensor.Text = sensor.Name;
            TbEditDescription.Text = sensor.Description;
        }

        private void btnLocationEdit_Click(object sender, EventArgs e)
        {
            dal.UpdateSensor(sensor.Id, TbNameEditSensor.Text, TbEditDescription.Text);
            dal.FillSensorListFromDatabase();
            this.Close();
        }

        private void BtnSensorMeasurements_Click(object sender, EventArgs e)

        {
            openChildForm(new SensorMeasurementsEditForm(dal, sensor));
            
        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            dal.FillSensorListFromDatabase();
            this.Close();
        }
    }
}
