﻿namespace ProFaceCountEnd
{
    partial class SensorEditForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PnlHeaderEditSensor = new System.Windows.Forms.Panel();
            this.LbHeaderLocation = new System.Windows.Forms.Label();
            this.btnLocationEdit = new System.Windows.Forms.Button();
            this.TbEditDescription = new System.Windows.Forms.TextBox();
            this.TbNameEditSensor = new System.Windows.Forms.TextBox();
            this.LbEditLocationMaxPersons = new System.Windows.Forms.Label();
            this.LbEditLocationName = new System.Windows.Forms.Label();
            this.BtnSensorMeasurements = new System.Windows.Forms.Button();
            this.BtnBack = new System.Windows.Forms.Button();
            this.PnlChildOpen = new System.Windows.Forms.Panel();
            this.PnlOpen = new System.Windows.Forms.Panel();
            this.PnlHeaderEditSensor.SuspendLayout();
            this.PnlChildOpen.SuspendLayout();
            this.PnlOpen.SuspendLayout();
            this.SuspendLayout();
            // 
            // PnlHeaderEditSensor
            // 
            this.PnlHeaderEditSensor.Controls.Add(this.BtnBack);
            this.PnlHeaderEditSensor.Controls.Add(this.LbHeaderLocation);
            this.PnlHeaderEditSensor.Dock = System.Windows.Forms.DockStyle.Top;
            this.PnlHeaderEditSensor.Location = new System.Drawing.Point(0, 0);
            this.PnlHeaderEditSensor.MinimumSize = new System.Drawing.Size(730, 49);
            this.PnlHeaderEditSensor.Name = "PnlHeaderEditSensor";
            this.PnlHeaderEditSensor.Size = new System.Drawing.Size(730, 49);
            this.PnlHeaderEditSensor.TabIndex = 0;
            // 
            // LbHeaderLocation
            // 
            this.LbHeaderLocation.AutoSize = true;
            this.LbHeaderLocation.Location = new System.Drawing.Point(103, 19);
            this.LbHeaderLocation.Name = "LbHeaderLocation";
            this.LbHeaderLocation.Size = new System.Drawing.Size(87, 19);
            this.LbHeaderLocation.TabIndex = 7;
            this.LbHeaderLocation.Text = "Edit sensor";
            // 
            // btnLocationEdit
            // 
            this.btnLocationEdit.Location = new System.Drawing.Point(182, 321);
            this.btnLocationEdit.Name = "btnLocationEdit";
            this.btnLocationEdit.Size = new System.Drawing.Size(139, 41);
            this.btnLocationEdit.TabIndex = 20;
            this.btnLocationEdit.Text = "Edit";
            this.btnLocationEdit.UseVisualStyleBackColor = true;
            this.btnLocationEdit.Click += new System.EventHandler(this.btnLocationEdit_Click);
            // 
            // TbEditDescription
            // 
            this.TbEditDescription.Location = new System.Drawing.Point(182, 279);
            this.TbEditDescription.Name = "TbEditDescription";
            this.TbEditDescription.Size = new System.Drawing.Size(139, 27);
            this.TbEditDescription.TabIndex = 19;
            // 
            // TbNameEditSensor
            // 
            this.TbNameEditSensor.Location = new System.Drawing.Point(182, 217);
            this.TbNameEditSensor.Name = "TbNameEditSensor";
            this.TbNameEditSensor.Size = new System.Drawing.Size(139, 27);
            this.TbNameEditSensor.TabIndex = 18;
            // 
            // LbEditLocationMaxPersons
            // 
            this.LbEditLocationMaxPersons.AutoSize = true;
            this.LbEditLocationMaxPersons.Location = new System.Drawing.Point(178, 257);
            this.LbEditLocationMaxPersons.Name = "LbEditLocationMaxPersons";
            this.LbEditLocationMaxPersons.Size = new System.Drawing.Size(94, 19);
            this.LbEditLocationMaxPersons.TabIndex = 17;
            this.LbEditLocationMaxPersons.Text = "Description";
            // 
            // LbEditLocationName
            // 
            this.LbEditLocationName.AutoSize = true;
            this.LbEditLocationName.Location = new System.Drawing.Point(178, 195);
            this.LbEditLocationName.Name = "LbEditLocationName";
            this.LbEditLocationName.Size = new System.Drawing.Size(58, 19);
            this.LbEditLocationName.TabIndex = 16;
            this.LbEditLocationName.Text = "Name";
            // 
            // BtnSensorMeasurements
            // 
            this.BtnSensorMeasurements.Location = new System.Drawing.Point(413, 250);
            this.BtnSensorMeasurements.Name = "BtnSensorMeasurements";
            this.BtnSensorMeasurements.Size = new System.Drawing.Size(168, 63);
            this.BtnSensorMeasurements.TabIndex = 21;
            this.BtnSensorMeasurements.Text = "Sensor measurements";
            this.BtnSensorMeasurements.UseVisualStyleBackColor = true;
            this.BtnSensorMeasurements.Click += new System.EventHandler(this.BtnSensorMeasurements_Click);
            // 
            // BtnBack
            // 
            this.BtnBack.Location = new System.Drawing.Point(12, 11);
            this.BtnBack.Name = "BtnBack";
            this.BtnBack.Size = new System.Drawing.Size(80, 34);
            this.BtnBack.TabIndex = 8;
            this.BtnBack.Text = "Back";
            this.BtnBack.UseVisualStyleBackColor = true;
            this.BtnBack.Click += new System.EventHandler(this.BtnBack_Click);
            // 
            // PnlChildOpen
            // 
            this.PnlChildOpen.Controls.Add(this.PnlHeaderEditSensor);
            this.PnlChildOpen.Controls.Add(this.BtnSensorMeasurements);
            this.PnlChildOpen.Controls.Add(this.LbEditLocationName);
            this.PnlChildOpen.Controls.Add(this.TbNameEditSensor);
            this.PnlChildOpen.Controls.Add(this.TbEditDescription);
            this.PnlChildOpen.Controls.Add(this.LbEditLocationMaxPersons);
            this.PnlChildOpen.Controls.Add(this.btnLocationEdit);
            this.PnlChildOpen.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PnlChildOpen.Location = new System.Drawing.Point(0, 0);
            this.PnlChildOpen.Name = "PnlChildOpen";
            this.PnlChildOpen.Size = new System.Drawing.Size(730, 530);
            this.PnlChildOpen.TabIndex = 22;
            // 
            // PnlOpen
            // 
            this.PnlOpen.Controls.Add(this.PnlChildOpen);
            this.PnlOpen.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PnlOpen.Location = new System.Drawing.Point(0, 0);
            this.PnlOpen.Name = "PnlOpen";
            this.PnlOpen.Size = new System.Drawing.Size(730, 530);
            this.PnlOpen.TabIndex = 23;
            // 
            // SensorEditForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(730, 530);
            this.Controls.Add(this.PnlOpen);
            this.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.MinimumSize = new System.Drawing.Size(730, 530);
            this.Name = "SensorEditForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SensorEditForm";
            this.Load += new System.EventHandler(this.SensorEditForm_Load);
            this.PnlHeaderEditSensor.ResumeLayout(false);
            this.PnlHeaderEditSensor.PerformLayout();
            this.PnlChildOpen.ResumeLayout(false);
            this.PnlChildOpen.PerformLayout();
            this.PnlOpen.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel PnlHeaderEditSensor;
        private System.Windows.Forms.Label LbHeaderLocation;
        private System.Windows.Forms.Button btnLocationEdit;
        private System.Windows.Forms.TextBox TbEditDescription;
        private System.Windows.Forms.TextBox TbNameEditSensor;
        private System.Windows.Forms.Label LbEditLocationMaxPersons;
        private System.Windows.Forms.Label LbEditLocationName;
        private System.Windows.Forms.Button BtnSensorMeasurements;
        private System.Windows.Forms.Button BtnBack;
        private System.Windows.Forms.Panel PnlChildOpen;
        private System.Windows.Forms.Panel PnlOpen;
    }
}